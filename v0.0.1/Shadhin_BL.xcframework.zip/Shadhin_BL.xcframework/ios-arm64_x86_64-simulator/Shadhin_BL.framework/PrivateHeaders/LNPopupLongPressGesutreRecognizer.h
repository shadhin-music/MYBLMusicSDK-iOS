//
//  LNPopupLongPressGesutreRecognizer.h
//  LNPopupController
//
//  Created by Leo Natan (Wix) on 15/07/2017.
//  Copyright © 2017 Leo Natan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LNPopupLongPressGesutreRecognizer : UILongPressGestureRecognizer

@end
